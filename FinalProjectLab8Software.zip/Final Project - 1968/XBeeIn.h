/*
 * Initializes XBee to receive input
 */
void XBeeInit();

/*
 * Gets input from XBee fifo
 */
 void XBeeIn();