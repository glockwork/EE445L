
void Timer0A_Init(void);

unsigned long INTPERIOD;
#define INTVARIATION 0

int timer_period = 50000;
unsigned long Count = 0;
unsigned long CountB = 0;
void portChanged(unsigned char port, unsigned char num);
